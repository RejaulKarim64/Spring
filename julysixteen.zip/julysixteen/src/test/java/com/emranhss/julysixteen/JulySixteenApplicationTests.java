package com.emranhss.julysixteen;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JulySixteenApplicationTests {

	@Test
	void contextLoads() {
	}

}
